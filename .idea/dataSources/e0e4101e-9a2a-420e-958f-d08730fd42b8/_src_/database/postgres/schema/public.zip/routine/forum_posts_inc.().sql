create function forum_posts_inc() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE forum
  SET postCount = postCount + 1
  WHERE forum.slug = new.forum;
  RETURN new;
END;
$$;
