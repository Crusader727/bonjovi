create function update_count_votes() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (TG_OP = 'UPDATE')
  THEN
    IF new.votes != old.votes
    THEN
      UPDATE thread
      SET votes = votes + (2 * new.votes)
      WHERE thread.tid = NEW.threadid;
      RETURN NEW;
    END IF;
    RETURN NEW;
  ELSE
    UPDATE thread
    SET votes = votes + new.votes
    WHERE thread.tid = NEW.threadid;
    RETURN NEW;
  END IF;
END;
$$;
