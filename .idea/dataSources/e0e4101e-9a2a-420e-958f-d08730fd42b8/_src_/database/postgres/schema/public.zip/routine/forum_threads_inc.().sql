create function forum_threads_inc() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE forum
  SET threadCount = threadCount + 1
  WHERE forum.slug = new.forum;
  INSERT INTO users_on_forum (nickname, slug, fullname, email, about)
    (SELECT
       new.owner,
       new.forum,
       u.fullname,
       u.email,
       u.about
     FROM users u
     WHERE lower(new.owner) = lower(u.nickname))
  ON CONFLICT DO NOTHING;
  RETURN new;
END;
$$;
