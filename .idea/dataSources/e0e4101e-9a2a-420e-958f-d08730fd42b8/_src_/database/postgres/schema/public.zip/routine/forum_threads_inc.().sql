create function forum_threads_inc() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE forum
  SET threadCount = threadCount + 1
  WHERE forum.slug = new.forum;
  RETURN new;
END;
$$;
